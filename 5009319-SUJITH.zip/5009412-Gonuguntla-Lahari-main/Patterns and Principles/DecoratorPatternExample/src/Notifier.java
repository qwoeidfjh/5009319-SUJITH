public interface Notifier {
    String send();
}