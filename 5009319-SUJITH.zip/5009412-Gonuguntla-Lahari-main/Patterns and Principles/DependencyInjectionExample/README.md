# Dependency Injection Example 11

The object is created elsewhere. The same type object is defined, and then injected into the class using it's constructor.

## Folder Structure

The workspace contains two folders by default, where:

- `src`: the folder to maintain sources
- `lib`: the folder to maintain dependencies

Meanwhile, the compiled output files will be generated in the `bin` folder by default.
