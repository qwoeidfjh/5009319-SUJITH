public class PayPalPayment implements PaymentStrategy {
    public void pay(){
        System.out.println("PayPalPayment");
    }
}
