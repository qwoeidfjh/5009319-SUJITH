public class Light {
    void turnOff(){
        System.out.println("Light is now Off !");
    }
    void turnOn(){
        System.out.println("Light is now On !");
    }
}
