public class StudentView {
    void displayStudentDetails(String name, String id, String grade){
        System.out.println("Student name : "+name);
        System.out.println("Student id : "+id);
        System.out.println("Student grade : "+grade);
    }
}
