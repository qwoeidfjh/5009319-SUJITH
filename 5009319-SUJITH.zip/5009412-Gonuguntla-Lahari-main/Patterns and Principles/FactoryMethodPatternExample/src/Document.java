public abstract class Document {
    public abstract void disp();
    public abstract void open();
    public abstract void save();
    public abstract void close();
}
