public class WordDocument extends Document {
    public void disp(){
        System.out.println("Word Document Generated");
    }
    public void open(){
        System.out.println("Opening Word Document...");
    }
    public void close(){
        System.out.println("Closing Word Document...");
    }
    public void save(){
        System.out.println("Svaing Word Document...");
    }
}
